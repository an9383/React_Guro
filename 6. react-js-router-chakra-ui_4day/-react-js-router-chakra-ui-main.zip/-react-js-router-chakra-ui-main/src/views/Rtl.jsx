import Layout from '../components/layout/Layout'

const Rtl = () => {
    return (
        <Layout title="rtl">
            <div>RTL 컨텐츠</div>
        </Layout>
    )
}

export default Rtl
