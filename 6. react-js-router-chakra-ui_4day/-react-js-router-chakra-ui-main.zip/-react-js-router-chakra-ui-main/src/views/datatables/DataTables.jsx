import Layout from '../../components/layout/Layout'

const DataTables = () => {
    return (
        <Layout title="DataTables">
            <div>데이터테이블 컨텐츠</div>
        </Layout>
    )
}

export default DataTables
