import Layout from '../../components/layout/Layout'

const Profile = () => {
    return (
        <>
            <div>프로필 컨텐츠</div>
        </>
    )
}

export default Profile
