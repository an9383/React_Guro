import styled from 'styled-components';

const Footer = () => {
    return <Ft>footer</Ft>;
};

const Ft = styled.footer`
    height: 100px;
    background-color: #eee;
`;

export default Footer;
