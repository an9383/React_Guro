import React from 'react'

function Viewer({ count }) {
    return (
        <div>
            <h1>{count}</h1>
        </div>
    )
}

export default Viewer
