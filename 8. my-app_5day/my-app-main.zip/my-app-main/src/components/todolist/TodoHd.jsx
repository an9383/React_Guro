import React from 'react'

export default function TodoHd() {
    return (
        <div style={{ border: '5px solid blue' }}>
            TodoHd.jsx
            <h1>📝 할 일 관리 앱</h1>
            <p>{new Date().toLocaleDateString()} 오늘의 할 일을 적어보세요.</p>
        </div>
    )
}
