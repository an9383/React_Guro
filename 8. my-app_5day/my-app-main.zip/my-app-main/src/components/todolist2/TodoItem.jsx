// 할 일 아이템의 수정 및 삭제

const TodoItem = () => {
    return (
        <div style={{ border: '5px solid orange' }}>
            TodoList.jsx
            <li>
                <input type="checkbox" />
                <span>관리비 납부하기</span>
                <span>2024.03.11</span>
                <button>삭제</button>
            </li>
        </div>
    )
}
export default TodoItem
