import React, { createContext } from 'react'

// Context 생성
const TimeContext = createContext()

export default TimeContext
