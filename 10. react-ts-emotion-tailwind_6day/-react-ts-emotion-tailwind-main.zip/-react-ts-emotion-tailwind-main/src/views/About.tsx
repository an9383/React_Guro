import React from 'react'

const About: React.FC = () => <div>About</div>

export default About
